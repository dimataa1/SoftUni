### ✅ Problem 2. Observations and Features

- **How many observations are there?**  
  **1,339 observations**  
  > Each row represents a coffee sample record with various attributes like origin, grading, and sensory scores.

- **How many features are there?**  
  **44 features (columns)**

- **Which features are numerical, and which are categorical?**

#### 📊 Numerical Features (16):
These represent measurable quantities:

- `Unnamed: 0`
- `Number.of.Bags`
- `Aroma`
- `Flavor`
- `Aftertaste`
- `Acidity`
- `Body`
- `Balance`
- `Cupper.Points`
- `Total.Cup.Points`
- `Moisture`
- `Category.Two.Defects`
- `altitude_low_meters`
- `altitude_high_meters`
- `altitude_mean_meters`
- `Category.One.Defects`

#### 🧾 Categorical Features (28):
These describe categories or labels:

- `Species`
- `Owner`
- `Country.of.Origin`
- `Farm.Name`
- `Lot.Number`
- `Mill`
- `ICO.Number`
- `Company`
- `Altitude`
- `Region`
- `Producer`
- `Bag.Weight`
- `In.Country.Partner`
- `Harvest.Year`
- `Grading.Date`
- `Owner.1`
- `Variety`
- `Processing.Method`
- `Color`
- `Expiration`
- `Certification.Body`
- `Certification.Address`
- `Certification.Contact`
- `unit_of_measurement`
- `Uniformity`
- `Clean.Cup`
- `Sweetness`
- `Quakers`

> *Note:* Some features are stored as numeric types but are **categorical in meaning** (e.g., `Uniformity`, `Sweetness`, `Quakers`).
